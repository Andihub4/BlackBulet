function BB() {
  
window.alert('Then click "Contact boss" button below to chat with the boss group ')

}
function BB0() {
  window.alert("So you have to close out.")
}