create table (name varchar(16),
Fname varchar(16),
age varchar(2),
Id primary key)

insert into student (name,Fname,age,Id)
values (@name , @Fname, @age ,@Id,@mark)

